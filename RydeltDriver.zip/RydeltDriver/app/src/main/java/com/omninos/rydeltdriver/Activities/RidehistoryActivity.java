package com.omninos.rydeltdriver.Activities;

import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.omninos.rydeltdriver.Fragments.UpcomingHistoryFragment;
import com.omninos.rydeltdriver.Fragments.OldHistoryFragment;
import com.omninos.rydeltdriver.R;

public class RidehistoryActivity extends AppCompatActivity implements View.OnClickListener {
    Button oldbtn,currentbtn;
    FragmentManager fm;
    ImageView back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ridehistory);

        oldbtn=findViewById(R.id.oldbtn);
        currentbtn=findViewById(R.id.currentbtn);
        oldbtn.setOnClickListener(this);
        currentbtn.setOnClickListener(this);
        back=findViewById(R.id.back);
        back.setOnClickListener(this);
        fm=getSupportFragmentManager();
        fm.beginTransaction().replace(R.id.frame,new UpcomingHistoryFragment()).commit();

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.oldbtn:
                currentbtn.setBackgroundResource(R.drawable.butn11);
                currentbtn.setTextColor(getResources().getColor(R.color.app_color));
                oldbtn.setBackgroundResource(R.drawable.button22);
                oldbtn.setTextColor(getResources().getColor(R.color.white));
                fm.beginTransaction().replace(R.id.frame,new OldHistoryFragment()).commit();
                break;
            case R.id.currentbtn:
                oldbtn.setBackgroundResource(R.drawable.button2);
                oldbtn.setTextColor(getResources().getColor(R.color.app_color));
                currentbtn.setBackgroundResource(R.drawable.buuton1);
                currentbtn.setTextColor(getResources().getColor(R.color.white));
                fm.beginTransaction().replace(R.id.frame,new UpcomingHistoryFragment()).commit();
                break;
            case R.id.back:
                onBackPressed();
                break;
        }
    }
}
