package com.omninos.rydeltdriver.Adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.omninos.rydeltdriver.R;

import java.util.List;

public class VehicleTypeAdapter extends RecyclerView.Adapter<VehicleTypeAdapter.ViewHolder> {
    private Context context;
    private int count = 0, row_index;


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.selecttypelayout, viewGroup, false);
        return new ViewHolder(view);
    }

    public VehicleTypeAdapter(Context context) {
        this.context = context;

    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder viewHolder, final int i) {
//        viewHolder.carname.setText(list.get(i).getTitle());
//        viewHolder.cardescription.setText(list.get(i).getDescription());
//        viewHolder.capacity.setText(list.get(i).getSeatCapacity() + " Max People");
//        Glide.with(context).load(list.get(i).getServiceImage1()).into(viewHolder.carimg);


        viewHolder.card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                row_index = i;
                count = 1;
                notifyDataSetChanged();

                if (row_index == i && count == 1) {
                    viewHolder.check.setVisibility(View.VISIBLE);
                    viewHolder.description.setVisibility(View.VISIBLE);


                } else {
                    viewHolder.check.setVisibility(View.GONE);
                    viewHolder.description.setVisibility(View.GONE);
                }
//                App.getSinltonPojo().setVehicletypeid(list.get(i).getId());
            }
        });

        if (row_index == i && count == 1) {
            viewHolder.check.setVisibility(View.VISIBLE);
            viewHolder.description.setVisibility(View.VISIBLE);
        } else {
            viewHolder.check.setVisibility(View.GONE);
            viewHolder.description.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return 3;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        CardView card;
        ImageView check, carimg;
        LinearLayout description;
        TextView carname, cardescription, capacity;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            card = itemView.findViewById(R.id.card);
            check = itemView.findViewById(R.id.check);
            description = itemView.findViewById(R.id.descriptionlayout);
            carimg = itemView.findViewById(R.id.carimage);
            carname = itemView.findViewById(R.id.carname);
            cardescription = itemView.findViewById(R.id.description);
            capacity = itemView.findViewById(R.id.capacity);
        }
    }
}

