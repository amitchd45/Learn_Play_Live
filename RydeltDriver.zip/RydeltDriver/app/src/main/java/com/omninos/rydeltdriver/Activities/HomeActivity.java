package com.omninos.rydeltdriver.Activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.infideap.drawerbehavior.AdvanceDrawerLayout;
import com.ncorti.slidetoact.SlideToActView;
import com.omninos.rydeltdriver.R;

public class HomeActivity extends AppCompatActivity implements View.OnClickListener {
    SlideToActView sta;
    ImageView navigation,profileimg;
    RelativeLayout rrl;
    LinearLayout rankinglayout;
    TextView username,wallettxt,documenttxt,historytxt,paybyaptxt,myvehicletxt,invitetxt,settingtxt,supporttxt,logoutxt,prioritytxt;

    AdvanceDrawerLayout advanceDrawerLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rrl=findViewById(R.id.rrl);
        rrl.setOnClickListener(this);
        advanceDrawerLayout=findViewById(R.id.advanceDrawerLayout);
        navigation=findViewById(R.id.navigation);
        navigation.setOnClickListener(this);
        profileimg=findViewById(R.id.profilePhoto);
        username=findViewById(R.id.username);
        wallettxt=findViewById(R.id.mywallettxt);
        documenttxt=findViewById(R.id.documentstxt);
        historytxt=findViewById(R.id.historytxt);
        paybyaptxt=findViewById(R.id.paybyapptxt);
        myvehicletxt=findViewById(R.id.myvehiceltxt);
        invitetxt=findViewById(R.id.invitetxt);
        settingtxt=findViewById(R.id.settingtxt);
        supporttxt=findViewById(R.id.supporttxt);
        logoutxt=findViewById(R.id.logouttxt);
        prioritytxt=findViewById(R.id.prioritytxt);
        rankinglayout=findViewById(R.id.rankinglayout);
        rankinglayout.setOnClickListener(this);
        prioritytxt.setOnClickListener(this);
        wallettxt.setOnClickListener(this);
        documenttxt.setOnClickListener(this);
        historytxt.setOnClickListener(this);
        paybyaptxt.setOnClickListener(this);
        myvehicletxt.setOnClickListener(this);
        invitetxt.setOnClickListener(this);
        settingtxt.setOnClickListener(this);
        supporttxt.setOnClickListener(this);
        logoutxt.setOnClickListener(this);


        performaction();

    }

    private void performaction() {
        advanceDrawerLayout.useCustomBehavior(Gravity.START);
        advanceDrawerLayout.setRadius(Gravity.START, 35);//set end container's corner radius (dimension)
        advanceDrawerLayout.setViewScale(Gravity.START, 0.9f);
        advanceDrawerLayout.setViewElevation(Gravity.START, 20);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.navigation:
            advanceDrawerLayout.openDrawer(Gravity.START);
                break;
            case R.id.rrl:
                startActivity(new Intent(HomeActivity.this,RideRequestActivity.class));
                break;
            case R.id.mywallettxt:
                startActivity(new Intent(HomeActivity.this,MyWalletActivity.class));

                break;
            case R.id.documentstxt:
                startActivity(new Intent(HomeActivity.this,UploadDocumentActivity.class));

                break;
            case R.id.historytxt:
                startActivity(new Intent(HomeActivity.this,RidehistoryActivity.class));

                break;
            case R.id.paybyapptxt:
                startActivity(new Intent(HomeActivity.this,PayByAppActivity.class));

                break;
            case R.id.myvehiceltxt:
                startActivity(new Intent(HomeActivity.this,MyVehicelActivtiy.class));

                break;
            case R.id.invitetxt:
                startActivity(new Intent(HomeActivity.this,InviteFriendsActivtiy.class));

                break;
            case R.id.settingtxt:
                startActivity(new Intent(HomeActivity.this,SettingActivity.class));

                break;
            case R.id.supporttxt:
                startActivity(new Intent(HomeActivity.this,SupportActivity.class));

                break;
            case R.id.logouttxt:
                startActivity(new Intent(HomeActivity.this,PhoneNumberActivity.class));
                break;
            case R.id.prioritytxt:
                startActivity(new Intent(HomeActivity.this,PriorityActivity.class));
                break;
            case R.id.rankinglayout:
                startActivity(new Intent(HomeActivity.this,PointsRankingActivity.class));
                break;
        }
    }
}
