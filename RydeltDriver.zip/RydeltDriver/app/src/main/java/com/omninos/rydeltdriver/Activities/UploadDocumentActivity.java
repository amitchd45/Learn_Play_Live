package com.omninos.rydeltdriver.Activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.omninos.rydeltdriver.R;

public class UploadDocumentActivity extends AppCompatActivity implements View.OnClickListener {
    ImageView back;
    RelativeLayout next;
    TextView policetxt, adharcard1txt, adhartxt2, drivingtxt, motortxt, registertxt, contactxt, checkleaftxt, pancardtxt;
    CardView policecard, adharcard1, adharcard2, drivingcard, motorcard, registrationcard, contactcard, checkleafcard, pancard;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_document);
        id();
    }

    private void id() {
        policecard = findViewById(R.id.policecard);
        adharcard1 = findViewById(R.id.adharcard1);
        adharcard2 = findViewById(R.id.adharcard2);
        drivingcard = findViewById(R.id.drivingcard);
        motorcard = findViewById(R.id.motorcard);
        registrationcard = findViewById(R.id.registercard);
        contactcard = findViewById(R.id.contactcard);
        checkleafcard = findViewById(R.id.cechleafcard);
        pancard = findViewById(R.id.pancard);
        policecard.setOnClickListener(this);
        adharcard2.setOnClickListener(this);
        adharcard1.setOnClickListener(this);
        drivingcard.setOnClickListener(this);
        motorcard.setOnClickListener(this);
        registrationcard.setOnClickListener(this);
        contactcard.setOnClickListener(this);
        checkleafcard.setOnClickListener(this);
        next=findViewById(R.id.next);
        next.setOnClickListener(this);
        pancard.setOnClickListener(this);
        adharcard1txt = findViewById(R.id.adharcrd1txt);
        adhartxt2 = findViewById(R.id.adharcard2txt);
        policetxt = findViewById(R.id.policetxt);
        drivingtxt = findViewById(R.id.drivingtxt);
        motortxt = findViewById(R.id.motortxt);
        registertxt = findViewById(R.id.registertxt);
        contactxt = findViewById(R.id.carriagetxt);
        pancardtxt = findViewById(R.id.pancdrtxt);
        back=findViewById(R.id.back);
        back.setOnClickListener(this);
        checkleaftxt = findViewById(R.id.checkleatxt);


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.next:
                startActivity(new Intent(UploadDocumentActivity.this, HomeActivity.class).putExtra("Status", "0"));

                break;
            case R.id.back:
                onBackPressed();
                break;
            case R.id.policecard:
//                App.getSinltonPojo().setPoliceverifyphoto("1");
//
//                App.getSinltonPojo().setAdharcard_frontphoto(null);
////                App.getSinltonPojo().setAdharcardnumber(null);
//                App.getSinltonPojo().setAdharcard_backPhoto(null);
//                App.getSinltonPojo().setDrivinglicensephoto(null);
////                App.getSinltonPojo().setLicensenumber(null);
////                App.getSinltonPojo().setLicenseexpirydate(null);
//                App.getSinltonPojo().setMotorinsurancephoto(null);
//                App.getSinltonPojo().setRegisterationphoto(null);
//                App.getSinltonPojo().setCarriagephoto(null);
//                App.getSinltonPojo().setCheckleafphoto(null);
//                App.getSinltonPojo().setPancardphoto(null);
//                App.getSinltonPojo().setRegistrationcertificateDate(null);
                startActivity(new Intent(UploadDocumentActivity.this, DocumentUploadActivity.class).putExtra("Status", "0"));

                break;
            case R.id.adharcard1:
//                App.getSinltonPojo().setAdharcard_frontphoto("1");
//                App.getSinltonPojo().setAdharcard_backPhoto(null);
//                App.getSinltonPojo().setDrivinglicensephoto(null);
//                App.getSinltonPojo().setMotorinsurancephoto(null);
//                App.getSinltonPojo().setCarriagephoto(null);
//                App.getSinltonPojo().setCheckleafphoto(null);
//                App.getSinltonPojo().setPancardphoto(null);
//                App.getSinltonPojo().setPoliceverifyphoto(null);
//                App.getSinltonPojo().setRegisterationphoto(null);
                startActivity(new Intent(UploadDocumentActivity.this, DocumentUploadActivity.class).putExtra("Status", "1"));

                break;
            case R.id.adharcard2:
//                App.getSinltonPojo().setAdharcard_backPhoto("1");
//                App.getSinltonPojo().setAdharcard_frontphoto(null);
//                App.getSinltonPojo().setDrivinglicensephoto(null);
//                App.getSinltonPojo().setMotorinsurancephoto(null);
//                App.getSinltonPojo().setRegisterationphoto(null);
//                App.getSinltonPojo().setCarriagephoto(null);
//                App.getSinltonPojo().setCheckleafphoto(null);
//                App.getSinltonPojo().setPancardphoto(null);
//                App.getSinltonPojo().setPoliceverifyphoto(null);
                startActivity(new Intent(UploadDocumentActivity.this, DocumentUploadActivity.class).putExtra("Status", "2"));

                break;
            case R.id.drivingcard:
//                App.getSinltonPojo().setDrivinglicensephoto("1");
//                App.getSinltonPojo().setAdharcard_backPhoto(null);
//                App.getSinltonPojo().setAdharcard_frontphoto(null);
//                App.getSinltonPojo().setMotorinsurancephoto(null);
//                App.getSinltonPojo().setRegisterationphoto(null);
//                App.getSinltonPojo().setCarriagephoto(null);
//                App.getSinltonPojo().setCheckleafphoto(null);
//                App.getSinltonPojo().setPancardphoto(null);
//                App.getSinltonPojo().setPoliceverifyphoto(null);
                startActivity(new Intent(UploadDocumentActivity.this, DocumentUploadActivity.class).putExtra("Status", "3"));

                break;
            case R.id.motorcard:
//                App.getSinltonPojo().setMotorinsurancephoto("1");
//                App.getSinltonPojo().setAdharcard_backPhoto(null);
//                App.getSinltonPojo().setDrivinglicensephoto(null);
////                App.getSinltonPojo().setLicensenumber(null);
////                App.getSinltonPojo().setLicenseexpirydate(null);
//                App.getSinltonPojo().setAdharcard_frontphoto(null);
//                App.getSinltonPojo().setCarriagephoto(null);
//                App.getSinltonPojo().setCheckleafphoto(null);
//                App.getSinltonPojo().setPancardphoto(null);
//                App.getSinltonPojo().setPoliceverifyphoto(null);
////                App.getSinltonPojo().setAdharcardnumber(null);
//                App.getSinltonPojo().setRegisterationphoto(null);
////                App.getSinltonPojo().setRegistrationcertificateDate(null);
                startActivity(new Intent(UploadDocumentActivity.this, DocumentUploadActivity.class).putExtra("Status", "4"));
                break;

            case R.id.registercard:

//                App.getSinltonPojo().setRegisterationphoto("1");
////                App.getSinltonPojo().setRegistrationcertificateDate("1");
//
//                App.getSinltonPojo().setAdharcard_backPhoto(null);
//                App.getSinltonPojo().setDrivinglicensephoto(null);
////                App.getSinltonPojo().setLicensenumber(null);
////                App.getSinltonPojo().setLicenseexpirydate(null);
//                App.getSinltonPojo().setMotorinsurancephoto(null);
//                App.getSinltonPojo().setCarriagephoto(null);
//                App.getSinltonPojo().setCheckleafphoto(null);
//                App.getSinltonPojo().setPancardphoto(null);
//                App.getSinltonPojo().setPoliceverifyphoto(null);
//                App.getSinltonPojo().setAdharcard_frontphoto(null);
//                App.getSinltonPojo().setAdharcardnumber(null);
                startActivity(new Intent(UploadDocumentActivity.this, DocumentUploadActivity.class).putExtra("Status", "5"));

                break;
            case R.id.contactcard:
//                App.getSinltonPojo().setCarriagephoto("1");
//
//                App.getSinltonPojo().setRegisterationphoto(null);
////                App.getSinltonPojo().setRegistrationcertificateDate(null);
//                App.getSinltonPojo().setAdharcard_backPhoto(null);
//                App.getSinltonPojo().setDrivinglicensephoto(null);
////                App.getSinltonPojo().setLicensenumber(null);
////                App.getSinltonPojo().setLicenseexpirydate(null);
//                App.getSinltonPojo().setMotorinsurancephoto(null);
//                App.getSinltonPojo().setCheckleafphoto(null);
//                App.getSinltonPojo().setPancardphoto(null);
//                App.getSinltonPojo().setPoliceverifyphoto(null);
//                App.getSinltonPojo().setAdharcard_frontphoto(null);
////                App.getSinltonPojo().setAdharcardnumber(null);
                startActivity(new Intent(UploadDocumentActivity.this, DocumentUploadActivity.class).putExtra("Status", "6"));

                break;
            case R.id.cechleafcard:
//                App.getSinltonPojo().setCheckleafphoto("1");
//
//                App.getSinltonPojo().setCarriagephoto(null);
//                App.getSinltonPojo().setRegisterationphoto(null);
////                App.getSinltonPojo().setRegistrationcertificateDate(null);
//                App.getSinltonPojo().setAdharcard_backPhoto(null);
//                App.getSinltonPojo().setDrivinglicensephoto(null);
////                App.getSinltonPojo().setLicensenumber(null);
////                App.getSinltonPojo().setLicenseexpirydate(null);
//                App.getSinltonPojo().setMotorinsurancephoto(null);
//                App.getSinltonPojo().setPancardphoto(null);
//                App.getSinltonPojo().setPoliceverifyphoto(null);
//                App.getSinltonPojo().setAdharcard_frontphoto(null);
//                App.getSinltonPojo().setAdharcardnumber(null);
                startActivity(new Intent(UploadDocumentActivity.this, DocumentUploadActivity.class).putExtra("Status", "7"));

                break;
            case R.id.pancard:
//                App.getSinltonPojo().setPancardphoto("1");
//
//                App.getSinltonPojo().setCheckleafphoto(null);
//                App.getSinltonPojo().setCarriagephoto(null);
//                App.getSinltonPojo().setRegisterationphoto(null);
////                App.getSinltonPojo().setRegistrationcertificateDate(null);
//                App.getSinltonPojo().setAdharcard_backPhoto(null);
//                App.getSinltonPojo().setDrivinglicensephoto(null);
////                App.getSinltonPojo().setLicensenumber(null);
////                App.getSinltonPojo().setLicenseexpirydate(null);
//                App.getSinltonPojo().setMotorinsurancephoto(null);
//                App.getSinltonPojo().setPoliceverifyphoto(null);
//                App.getSinltonPojo().setAdharcard_frontphoto(null);
//                App.getSinltonPojo().setAdharcardnumber(null);
                startActivity(new Intent(UploadDocumentActivity.this, DocumentUploadActivity.class).putExtra("Status", "8"));

                break;

        }
    }
}
