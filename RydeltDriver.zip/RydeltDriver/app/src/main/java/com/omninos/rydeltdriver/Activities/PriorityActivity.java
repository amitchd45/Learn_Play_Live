package com.omninos.rydeltdriver.Activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;

import com.omninos.rydeltdriver.Adapters.PriorityAdapter;
import com.omninos.rydeltdriver.R;

public class PriorityActivity extends AppCompatActivity implements View.OnClickListener {
        private ImageView back;
        private RecyclerView rv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_priority);

        back=findViewById(R.id.back);
        rv=findViewById(R.id.rv);
        back.setOnClickListener(this);

        setAdapetr();

    }

    private void setAdapetr() {
        rv.setLayoutManager(new LinearLayoutManager(PriorityActivity.this,LinearLayoutManager.HORIZONTAL,false));
        PriorityAdapter adapter=new PriorityAdapter(PriorityActivity.this);
        rv.setAdapter(adapter);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.back:
                onBackPressed();
                break;
        }
    }
}
