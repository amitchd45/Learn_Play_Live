package com.omninos.rydeltdriver.Activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;

import com.omninos.rydeltdriver.R;

public class PhoneNumberActivity extends AppCompatActivity implements View.OnClickListener {
    private RelativeLayout nextBtnPhoneRl;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phone_number);

        nextBtnPhoneRl=findViewById(R.id.nextBtnPhoneRl);
        nextBtnPhoneRl.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.nextBtnPhoneRl:
                startActivity(new Intent(PhoneNumberActivity.this,OtpActivtiy.class));
                break;
        }
    }
}
