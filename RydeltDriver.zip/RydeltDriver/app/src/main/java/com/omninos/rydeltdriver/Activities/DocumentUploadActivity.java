package com.omninos.rydeltdriver.Activities;

import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.omninos.rydeltdriver.R;

import java.io.File;

public class DocumentUploadActivity extends AppCompatActivity implements View.OnClickListener {
    private LinearLayout numberlayout, expirydatelayout;
    private ImageView back, image, addimage;
    private TextView actionbar, expiryDate;
    private Button done;
    private String position,numberstring,numberstring2;
    private File photoFile;
    private EditText numberet;
    private Uri uri;
    private String imagepath, UserimagePath = "", licencenostr;
    private Button buttonDone;
    private static final int GALLERY_REQUEST = 101;
    private static final int CAMERA_REQUEST = 102;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_document_upload);
            id();
    }

    private void id() {
        numberlayout = findViewById(R.id.numberlayout);
        expirydatelayout = findViewById(R.id.expirydatelayout);
        back = findViewById(R.id.back);
        done = findViewById(R.id.buttonDone);
        back.setOnClickListener(this);
        actionbar = findViewById(R.id.actionbar);
        done.setOnClickListener(this);
        image = findViewById(R.id.image);
        addimage = findViewById(R.id.addimage);
        addimage.setOnClickListener(this);
        numberet=findViewById(R.id.numberet);
        expiryDate = findViewById(R.id.expiryDate);
        expiryDate.setOnClickListener(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        position = getIntent().getStringExtra("Status");
        if (position.equalsIgnoreCase("0")) {
            actionbar.setText("Police Vertification");
            expirydatelayout.setVisibility(View.GONE);
            numberlayout.setVisibility(View.GONE);

        } else if (position.equalsIgnoreCase("1")) {
            actionbar.setText("Aadhar Card (Front)");
            expirydatelayout.setVisibility(View.GONE);
            numberstring=numberet.getText().toString();

        } else if (position.equalsIgnoreCase("2")) {
            actionbar.setText("Aadhar Card (Back)");
            expirydatelayout.setVisibility(View.GONE);
            numberlayout.setVisibility(View.GONE);


        } else if (position.equalsIgnoreCase("3")) {
            actionbar.setText("Driving License ");
            expirydatelayout.setVisibility(View.VISIBLE);
            numberlayout.setVisibility(View.VISIBLE);
            numberstring2=numberet.getText().toString();

        } else if (position.equalsIgnoreCase("5")) {
            actionbar.setText("Certificate of registration");
            expirydatelayout.setVisibility(View.VISIBLE);
            numberlayout.setVisibility(View.GONE);

        } else if (position.equalsIgnoreCase("4")) {
            actionbar.setText("Motor Insurance certificate");
            expirydatelayout.setVisibility(View.GONE);
            numberlayout.setVisibility(View.GONE);


        } else if (position.equalsIgnoreCase("6")) {
            actionbar.setText("Contact Carriage Permit");
            expirydatelayout.setVisibility(View.GONE);
            numberlayout.setVisibility(View.GONE);


        } else if (position.equalsIgnoreCase("7")) {
            actionbar.setText("Check leaf");
            expirydatelayout.setVisibility(View.GONE);
            numberlayout.setVisibility(View.GONE);


        } else if (position.equalsIgnoreCase("8")) {
            actionbar.setText("Pan Card");
            expirydatelayout.setVisibility(View.GONE);
            numberlayout.setVisibility(View.GONE);

        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.back:
                onBackPressed();
                break;

        }
    }
}
