package com.omninos.rydeltdriver.Activities;

import android.content.Intent;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.RelativeLayout;

import com.omninos.rydeltdriver.R;

public class OtpActivtiy extends AppCompatActivity implements View.OnClickListener {
    private EditText otp1, otp2, otp3, otp4, otp5, otp6;
    private RelativeLayout nextBtnOtpRl;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp_activtiy);
        findIds();
        OTPCode();

    }
        private void findIds() {
            nextBtnOtpRl = findViewById(R.id.nextBtnOtpRl);
            nextBtnOtpRl.setOnClickListener(this);

            otp1 = findViewById(R.id.otp1);
            otp2 = findViewById(R.id.otp2);
            otp3 = findViewById(R.id.otp3);
            otp4 = findViewById(R.id.otp4);
            otp5 = findViewById(R.id.otp5);
            otp6 = findViewById(R.id.otp6);
        }

        @Override
        public void onClick(View view) {
            switch (view.getId()){
                case R.id.nextBtnOtpRl:
                    startActivity(new Intent(this, ProfileActivity.class));
                    break;
            }
        }

        private void OTPCode() {

            otp1.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {

                }


                @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
                @Override
                public void afterTextChanged(Editable s) {

                    if (s.length() == 1) {
                        otp2.requestFocus();
                        otp1.setElevation(1);
                    } else if (s.length() == 0) {

                    }
                }
            });

            otp2.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {

                }

                @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
                @Override
                public void afterTextChanged(Editable s) {
                    if (s.length() == 1) {
                        otp3.requestFocus();
                        otp2.setElevation(1);
                    } else if (s.length() == 0) {

                        otp1.requestFocus();
                    }
                }
            });

            otp3.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {

                }


                @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
                @Override
                public void afterTextChanged(Editable s) {

                    if (s.length() == 1) {
                        otp4.requestFocus();
                        otp3.setElevation(1);
                    } else if (s.length() == 0) {
                        otp2.requestFocus();
                    }
                }
            });

            otp4.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {

                }


                @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
                @Override
                public void afterTextChanged(Editable s) {

                    if (s.length() == 1) {
                        otp5.requestFocus();
                        otp4.setElevation(1);
                    } else if (s.length() == 0) {
                        otp3.requestFocus();
                    }
                }
            });

            otp5.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {

                }


                @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
                @Override
                public void afterTextChanged(Editable s) {

                    if (s.length() == 1) {
                        otp6.requestFocus();
                        otp5.setElevation(1);
                    } else if (s.length() == 0) {
                        otp4.requestFocus();
                    }
                }
            });

            otp6.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {

                }

                @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
                @Override
                public void afterTextChanged(Editable s) {

                    if (s.length() == 1) {
                        otp6.setElevation(1);
                    } else if (s.length() == 0) {
                        otp5.requestFocus();
                    }
                }
            });

        }


}
