package com.omninos.rydeltdriver.Activities;

import android.content.Intent;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.omninos.rydeltdriver.R;

import in.shadowfax.proswipebutton.ProSwipeButton;

public class RideRequestActivity extends AppCompatActivity implements View.OnClickListener {
    private ProSwipeButton swipebutton;
    private ImageView cancel,userimage;
    private ProgressBar barTimer;

    private int autoCancelJob=1;
    private TextView textTimer,payment,paymenttypetxt,sourceadress,destinationaddress,username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ride_request);
        intIds();
        startTimer();
        performActions();

    }

    private void intIds() {


        barTimer=findViewById(R.id.barTimer);
        textTimer=findViewById(R.id.textTimer);
        swipebutton = findViewById(R.id.swipebutton);
        cancel = findViewById(R.id.cancel);
        cancel.setOnClickListener(this);
        payment=findViewById(R.id.price);
        paymenttypetxt=findViewById(R.id.paymnettype);
        userimage=findViewById(R.id.userImage);
        username=findViewById(R.id.username);
        sourceadress=findViewById(R.id.sourceadress);
        destinationaddress=findViewById(R.id.destinationadress);

        swipebutton.setOnSwipeListener(new ProSwipeButton.OnSwipeListener() {
            @Override
            public void onSwipeConfirm() {
                swipebutton.showResultIcon(true,false);
                startActivity(new Intent(RideRequestActivity.this,ArrivingActivity.class));
                //acceptJobApi("1");
            }
        });
    }
    private void startTimer() {

        new CountDownTimer(30 * 1000, 500) {
            @Override
            public void onTick(long leftTimeInMilliseconds) {
                long seconds = leftTimeInMilliseconds / 1000;
                barTimer.setProgress((int) seconds);
                textTimer.setText(String.format("%02d", seconds / 60) + ":" + String.format("%02d", seconds % 60));
                // format the textview to show the easily readable format
            }

            @Override
            public void onFinish() {
                if (textTimer.getText().equals("00:00")) {
                    if (autoCancelJob == 1) {
                      //  acceptJobApi("2");
                    }
                } else {
                    textTimer.setText("00:30");
                    barTimer.setProgress(100);
                }
            }
        }.start();
    }
    private void performActions() {
        cancel.setOnClickListener(this);
        swipebutton.setSwipeDistance(0.5f);
    }

    @Override
    public void onClick(View v) {
            switch (v.getId()){
                case R.id.cancel:
                    break;
            }
    }
}
