package com.omninos.rydeltdriver.Activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.omninos.rydeltdriver.R;

public class PayByAppActivity extends AppCompatActivity implements View.OnClickListener {
        ImageView back;
        Button Submit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pay_by_app);

        back=findViewById(R.id.back);
        back.setOnClickListener(this);
        Submit=findViewById(R.id.buttonDone);
        Submit.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.back:
                onBackPressed();
                break;
            case R.id.buttonDone:
                startActivity(new Intent(PayByAppActivity.this,PriorityActivity.class));
                break;
        }
    }
}
