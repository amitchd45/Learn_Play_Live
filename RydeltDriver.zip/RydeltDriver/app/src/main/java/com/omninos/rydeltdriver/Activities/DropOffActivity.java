package com.omninos.rydeltdriver.Activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

import com.omninos.rydeltdriver.R;

import in.shadowfax.proswipebutton.ProSwipeButton;

public class DropOffActivity extends AppCompatActivity {
    ProSwipeButton swipebutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_drop_off);

        swipebutton=findViewById(R.id.swipebutton);
        swipebutton.setOnSwipeListener(new ProSwipeButton.OnSwipeListener() {
            @Override
            public void onSwipeConfirm() {
                swipebutton.showResultIcon(true,false);
                startActivity(new Intent(DropOffActivity.this,RatingActivtiy.class));
                //acceptJobApi("1");
            }
        });
    }
}
