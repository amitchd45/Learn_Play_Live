package com.omninos.rydeltdriver.Activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.omninos.rydeltdriver.R;


import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileActivity extends AppCompatActivity implements View.OnClickListener {
    private Spinner accountTypeSpinner;
    private CircleImageView civ_profile, addNewImage;
    private String imagepath="";
    private RelativeLayout nextBtnOtpRl;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        findIds();
        spinners();

    }

    private void findIds() {
        nextBtnOtpRl = findViewById(R.id.nextBtnOtpRl);
        nextBtnOtpRl.setOnClickListener(this);
        accountTypeSpinner = findViewById(R.id.accountTypeSpinner);
        civ_profile = findViewById(R.id.civ_profile);
        addNewImage = findViewById(R.id.addNewImage);
        addNewImage.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.addNewImage:
                //OpenGallery();
                break;
            case R.id.nextBtnOtpRl:
                startActivity(new Intent(this, PasswordActivity.class));
                break;
        }
    }

//    private void OpenGallery(){
//
//        CropImage.activity()
//                .setGuidelines(CropImageView.Guidelines.ON)
//                .start(this);
//    }
//
//    @Override
//    public void onActivityResult(int requestCode, int resultCode, Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
//            CropImage.ActivityResult result = CropImage.getActivityResult(data);
//            if (resultCode == RESULT_OK) {
//                String resultUri = result.getUri().getPath();
//                Glide.with(this).load(resultUri).into(civ_profile);
//                imagepath = resultUri;
//            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
//                Exception error = result.getError();
//            }
//        }
//    }

    private void spinners() {
        Spinner chooseVenueCitySpinner = findViewById(R.id.accountTypeSpinner);

        ArrayAdapter<String> chooseVenueCityAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, android.R.id.text1);
        chooseVenueCityAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        chooseVenueCitySpinner.setAdapter(chooseVenueCityAdapter);
        chooseVenueCityAdapter.add("VIP");
        chooseVenueCityAdapter.add("Normal");
        chooseVenueCityAdapter.add("VIP");
        chooseVenueCityAdapter.notifyDataSetChanged();

        chooseVenueCitySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                ((TextView) parent.getChildAt(0)).setTextColor(getResources().getColor(R.color.app_color));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }


}
