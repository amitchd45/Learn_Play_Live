package com.omninos.rydeltdriver.Activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.omninos.rydeltdriver.R;

import in.shadowfax.proswipebutton.ProSwipeButton;

public class ArrivingActivity extends AppCompatActivity {
    private ProSwipeButton swipebutton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_arriving);
        swipebutton=findViewById(R.id.swipebutton);
        swipebutton.setOnSwipeListener(new ProSwipeButton.OnSwipeListener() {
            @Override
            public void onSwipeConfirm() {
                swipebutton.showResultIcon(true,false);
                startActivity(new Intent(ArrivingActivity.this,StartJobActivtiy.class));
                //acceptJobApi("1");
            }
        });

    }
}
