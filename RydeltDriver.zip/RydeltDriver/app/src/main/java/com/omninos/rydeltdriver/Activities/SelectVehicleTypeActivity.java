package com.omninos.rydeltdriver.Activities;

import android.arch.lifecycle.Observer;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.omninos.rydeltdriver.Adapters.VehicleTypeAdapter;
import com.omninos.rydeltdriver.R;

public class SelectVehicleTypeActivity extends AppCompatActivity implements View.OnClickListener {
    private RecyclerView vehiclerv;
    private RelativeLayout nextBtnPhoneRl;
    private ImageView back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_vehicle_type);
        intIds();
        performActions();

    }

    private void intIds() {
        vehiclerv = findViewById(R.id.vehiclerv);
        nextBtnPhoneRl = findViewById(R.id.nextBtnPhoneRl);
        back=findViewById(R.id.back);
        back.setOnClickListener(this);
    }

    private void performActions() {
        nextBtnPhoneRl.setOnClickListener(this);
        vehiclerv.setLayoutManager(new LinearLayoutManager(SelectVehicleTypeActivity.this, LinearLayoutManager.VERTICAL, false));

        VehicleTypeAdapter adapter = new VehicleTypeAdapter(SelectVehicleTypeActivity.this);
        vehiclerv.setAdapter(adapter);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.nextBtnPhoneRl:
                startActivity(new Intent(SelectVehicleTypeActivity.this,AddVehicleActivity.class));
                break;
            case R.id.back:
                onBackPressed();
                break;
        }


    }
}
